"use client";

import React, { useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Row, Col } from "react-bootstrap";

import AcountHeader from "@/components/AcountHeader";
import SideBar from "@/components/SideBar";

import { MailPlus, ImagePlus, Star, X, MessageCircleMore } from "lucide-react";

import { Fancybox } from "@fancyapps/ui";
import "@fancyapps/ui/dist/fancybox/fancybox.css";

import Primium from "@/components/Primium";
import ProfileSearch from "@/components/ProfileSearch";

function Page() {
  const router = useRouter();

  useEffect(() => {
    Fancybox.bind("[data-fancybox]", {
      animated: true,
      showClass: "f-fadeIn",
      hideClass: "f-fadeOut",
      dragToClose: true,
      Toolbar: {
        display: {
          left: [],
          middle: [],
          right: ["close"],
        },
      },
      Thumbs: {
        type: "classic",
      },
    });

    return () => {
      Fancybox.destroy();
    };
  }, []);

  const profiles = [
    {
      id: 1,
      name: "A Shab",
      age: 26,
      location: "Durgapur",
      caste: "Bania",
      height: "5ft 2in",
      work: "Student",
      income: "No Income",
      education: "M.Com",
      managedBy: "Self",
      active: "Active Today",
      compatible: "Most Compatible",
      nearby: "Nearby",
      images: [
        "/images/matches/no-1.jpg",
        "/images/matches/no-2.jpg",
        "/images/matches/no-3.jpg",
        "/images/matches/no-4.jpg",
      ],
    },
    {
      id: 2,
      name: "Debasmita Saha",
      age: 24,
      location: "Durgapur",
      caste: "Kayastha",
      height: "5ft 3in",
      work: "Not planning to work",
      income: "No Income",
      education: "B.Sc",
      managedBy: "Self",
      active: "Active Today",
      compatible: "Most Compatible",
      nearby: "Nearby",
      images: [
        "/images/matches/no-2.jpg",
        "/images/matches/no-3.jpg",
        "/images/matches/no-4.jpg",
        "/images/matches/no-5.jpg",
      ],
    },
    {
      id: 3,
      name: "Ananya",
      age: 25,
      location: "Kolkata",
      caste: "Brahmin",
      height: "5ft 4in",
      work: "Software Professional",
      income: "₹5 Lakh",
      education: "B.Tech",
      managedBy: "Self",
      active: "Active Today",
      compatible: "Good Match",
      nearby: "Nearby",
      images: [
        "/images/matches/no-3.jpg",
        "/images/matches/no-4.jpg",
        "/images/matches/no-5.jpg",
        "/images/matches/no-1.jpg",
      ],
    },
    {
      id: 4,
      name: "A Shab",
      age: 26,
      location: "Durgapur",
      caste: "Bania",
      height: "5ft 2in",
      work: "Student",
      income: "No Income",
      education: "M.Com",
      managedBy: "Self",
      active: "Active Today",
      compatible: "Top Profile",
      nearby: "Nearby",
      images: [
        "/images/matches/no-4.jpg",
        "/images/matches/no-2.jpg",
        "/images/matches/no-3.jpg",
        "/images/matches/no-4.jpg",
      ],
    },
    {
      id: 5,
      name: "Debasmita Saha",
      age: 24,
      location: "Durgapur",
      caste: "Kayastha",
      height: "5ft 3in",
      work: "Not planning to work",
      income: "No Income",
      education: "B.Sc",
      managedBy: "Self",
      active: "Active Today",
      compatible: "Most Compatible",
      nearby: "Nearby",
      images: [
        "/images/matches/no-5.jpg",
        "/images/matches/no-3.jpg",
        "/images/matches/no-4.jpg",
        "/images/matches/no-5.jpg",
      ],
    },
  ];

  const getTagClass = (tag) => {
    switch (tag) {
      case "Most Compatible":
        return "tag-most-compatible";

      case "Good Match":
        return "tag-good-match";

      case "Top Profile":
        return "tag-top-profile";

      case "New Profile":
        return "tag-new-profile";

      case "Highly Recommended":
        return "tag-highly-recommended";

      default:
        return "tag-default";
    }
  };

  const handleCardClick = (profileId) => {
    router.push(`/matches/${profileId}`);
  };

  return (
    <>
      <AcountHeader />

      <SideBar>
        <div className="dashboard-page">
          <Row>
            <Col xl={9}>
              <div className="matches-search-wrapper">
                <ProfileSearch />
              </div>

              <Row className="matches-profile-row">
                {profiles.map((profile) => (
                  <Col xs={12} sm={6} lg={4} key={profile.id} className="mb-4">
                    <div
                      className="mateches-profile"
                      onClick={() => handleCardClick(profile.id)}
                      role="link"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          handleCardClick(profile.id);
                        }
                      }}
                    >
                      <img
                        className="profile-card-image"
                        src={profile.images[0]}
                        alt={profile.name}
                      />

                      <div className="details-overlay">
                        <div className="profile-card-top">
                          <div
                            className={`tag ${getTagClass(profile.compatible)}`}
                          >
                            {profile.compatible}
                          </div>

                          <div className="profile-card-top-right">
                            <div
                              className="more-images"
                              data-fancybox={`profile-${profile.id}`}
                              data-src={profile.images[0]}
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                              }}
                            >
                              <ImagePlus size={14} />
                              <span>{profile.images.length}</span>
                            </div>
                          </div>
                        </div>

                        <div className="profile-card-content">
                          <div className="activity">{profile.active}</div>

                          <div className="name">
                            {profile.name}, <span>{profile.age}</span>
                          </div>

                          <div className="profile-details">
                            <span>
                              {profile.height} • {profile.location} •{" "}
                              {profile.caste}
                            </span>

                            <span>
                              {profile.work} • {profile.income}
                            </span>

                            <span>{profile.education}</span>
                          </div>

                          <div className="tag-badge">
                            Profile managed by <span>{profile.managedBy}</span>
                          </div>
                        </div>

                        <div className="overlay-footer">
                          <div
                            className="overlay-item"
                            onClick={(e) => {
                              e.stopPropagation();
                            }}
                          >
                            <MailPlus size={17} />
                            <span>Interest</span>
                          </div>

                          <div
                            className="overlay-item"
                            onClick={(e) => {
                              e.stopPropagation();
                            }}
                          >
                            <Star size={17} />
                            <span>Shortlist</span>
                          </div>

                          <div
                            className="overlay-item"
                            onClick={(e) => {
                              e.stopPropagation();
                            }}
                          >
                            <X size={17} />
                            <span>Ignore</span>
                          </div>

                          <Link
                            href={`/messages/${profile.id}`}
                            className="overlay-item"
                            onClick={(e) => {
                              e.stopPropagation();
                            }}
                          >
                            <MessageCircleMore size={17} />
                            <span>Chat</span>
                          </Link>
                        </div>
                      </div>

                      <div className="fancybox-hidden-gallery">
                        {profile.images.slice(1).map((image, index) => (
                          <a
                            key={index}
                            href={image}
                            data-fancybox={`profile-${profile.id}`}
                            data-caption={`${profile.name} - ${index + 2}`}
                          >
                            <img
                              src={image}
                              alt={`${profile.name} ${index + 2}`}
                            />
                          </a>
                        ))}
                      </div>
                    </div>
                  </Col>
                ))}
              </Row>
            </Col>

            <Col xl={3}>
              <div className="dashboard-premium-sticky">
                <Primium />
              </div>
            </Col>
          </Row>
        </div>
      </SideBar>
    </>
  );
}

export default Page;
